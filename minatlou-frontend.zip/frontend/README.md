# Minatlou Security & Projects — Frontend

Production-ready frontend for the Minatlou Security & Projects website and
job portal. Built as static HTML/CSS/JS (no build step required) so it can
be deployed as-is to any static host, then wired to a real backend API.

## Project Structure

```
frontend/
├── index.html            Home page
├── about.html             About page
├── services.html          Services page
├── gallery.html            Gallery page + lightbox
├── contact.html            Contact page
├── careers.html            Job listings (search + filter)
├── job-details.html        Single job description
├── login.html               Sign in
├── register.html            Create account
├── forgot-password.html     Password reset request
├── dashboard.html            Applicant dashboard (profile + applications)
├── apply.html                 Job application flow (pre-fill + file uploads)
├── css/
│   ├── base.css            Original brand styles (colors, type, layout) — unchanged
│   └── pages.css           New component styles for the job portal, matching base.css
├── js/
│   ├── api.js               Central API service layer — every backend call goes through here
│   ├── auth.js               Session/token storage helpers
│   ├── partials.js            Shared navbar + footer markup, injected on every page
│   ├── nav.js                  Mobile menu, active nav link, back-to-top, scroll reveal
│   ├── quote-modal.js           "Get a Quote" modal (marketing pages)
│   ├── job-card.js               Job card renderer used by careers.html
│   ├── file-upload.js             Reusable drag/drop + validated file upload widget
│   └── ui.js                       Toast notifications, form error helpers
└── assets/
    └── img/                        Site images (extracted from the original design)
```

No page duplicates the navbar/footer markup — `js/partials.js` injects it
into every page's `<div id="site-navbar"></div>` / `<div id="site-footer"></div>`
mount points, so branding edits only need to happen in one place.

## Brand System (do not change without client sign-off)

All colors, fonts, spacing and component styles live in `css/base.css` and
are reused as CSS variables (`--blue`, `--red`, `--dark`, `--grey`, etc.)
throughout `css/pages.css`. The job portal pages were built to visually
match the existing site exactly — same card shadows, same button styles,
same section rhythm.

## Connecting to a Real Backend

Every network call in the app is routed through `js/api.js`. To go live:

1. Set `window.MINATLOU_API_BASE_URL` (e.g. in a small inline `<script>`
   before `api.js` loads) to your production API origin, **or** edit the
   `API_BASE_URL` default at the top of `js/api.js`.
2. Remove the `FALLBACK_*` sample-data blocks in `careers.html`,
   `job-details.html`, and `dashboard.html` — they only exist so the UI is
   demonstrable before the backend is connected, and are clearly marked
   with comments.
3. Confirm your API's response shapes match what each page expects (see
   the JSDoc comments above each function in `js/api.js`), or adjust the
   small amount of "unwrap" code in each page's inline `<script>`
   (e.g. `data.jobs || data`).

### Endpoints Consumed

| Method | Endpoint                         | Used By              | Notes |
|--------|-----------------------------------|-----------------------|-------|
| POST   | `/api/auth/register`              | register.html         | body: `{ fullName, email, password, phone }` |
| POST   | `/api/auth/login`                 | login.html            | body: `{ email, password }` → `{ token, user }` |
| POST   | `/api/auth/forgot-password`       | forgot-password.html  | body: `{ email }` |
| GET    | `/api/jobs`                       | careers.html          | query: `search`, `location`, `type` |
| GET    | `/api/jobs/:id`                   | job-details.html, apply.html | |
| POST   | `/api/applications/:jobId`        | apply.html             | multipart FormData: `fullName`, `email`, `phone`, `cv`, `documents[]` |
| GET    | `/api/applications`               | dashboard.html         | current user's applications |
| GET    | `/api/profile`                     | dashboard.html          | current user's profile |
| PATCH  | `/api/profile`                     | (available in api.js)  | not yet wired to a page |

### Auth

Bearer token auth. `js/auth.js` stores the token and a light user snapshot
in `localStorage` after a successful login/register, and `js/api.js`
automatically attaches `Authorization: Bearer <token>` to any authenticated
request. Pages that require a session call `Auth.requireAuth()` at the top
of their inline script, which redirects to `login.html?next=<page>` if
there's no active session.

### Security Note

User-supplied filenames (CV, supporting documents) are HTML-escaped before
rendering. Job listings, job details, and profile/application data returned
by the API are rendered as-is; the backend should sanitize any
user-generated fields it stores (e.g. job descriptions written via an admin
panel) before returning them, since this frontend does not re-sanitize
API response content.

## File Upload Validation

`js/file-upload.js` provides a reusable, dependency-free upload widget
(click-to-browse + drag & drop) used for both the CV field (single file)
and supporting documents (multiple files) on `apply.html`. It validates:

- **Type**: PDF, DOC, DOCX only (both MIME type and extension checked)
- **Size**: 5MB max per file (configurable via `maxSizeMB`)

Invalid files are shown inline with an error message and are excluded from
`getFiles()`, so a partially-invalid selection can't be silently submitted.

## Local Preview

No build tooling is required — just serve the folder statically, e.g.:

```
cd frontend
python3 -m http.server 8080
```

Then open `http://localhost:8080/index.html`.
